import React, { useEffect, useRef } from 'react';

const CameraFeed = ({ exerciseType }) => {
  const videoUrl = `http://localhost:5000/video_feed?exercise_type=${exerciseType}`;
  const imgRef = useRef(null);

  useEffect(() => {
    const controller = new AbortController();
    const signal = controller.signal;

    // Set the image source
    if (imgRef.current) {
      imgRef.current.src = videoUrl;
    }

    // Cleanup function to stop the video feed
    return () => {
      controller.abort();
      if (imgRef.current) {
        imgRef.current.src = ''; // Clear the image source
      }
    };
  }, [videoUrl]);

  return (
    <div style={{ width: '100%', textAlign: 'center' }}>
      <img
        ref={imgRef}
        alt="Exercise Tracking"
        style={{
          width: '100%',
          maxWidth: '640px',
          borderRadius: '10px',
          boxShadow: '0 0 10px rgba(0,0,0,0.3)',
        }}
      />
      <p style={{ marginTop: '10px' }}>Tracking: {exerciseType}</p>
    </div>
  );
};

export default CameraFeed;
