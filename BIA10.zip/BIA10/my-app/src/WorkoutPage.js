import React, { useState } from 'react';
import { X, Search, ChevronDown, Play } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import CameraFeed from './components/CameraFeed';
import './WorkoutPage.css';

const WorkoutPage = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [videoModalOpen, setVideoModalOpen] = useState(false);
  const [selectedExercise, setSelectedExercise] = useState(null);
  const [showCamera, setShowCamera] = useState(false);


  const categories = ['All', 'Upper Body', 'Lower Body', 'Core', 'Cardio', 'Full Body'];

  const exercises = [
    { id: 1, name: 'Push-ups', category: 'Upper Body', difficulty: 'Beginner', muscles: 'Chest, Shoulders, Triceps', instructions: 'Start in a plank position...', image: '/assets/exercises/push-ups.jpg' },
    { id: 2, name: 'Squats', category: 'Lower Body', difficulty: 'Beginner', muscles: 'Quads, Hamstrings, Glutes', instructions: 'Stand with feet shoulder-width apart...', image: '/assets/exercises/squats.jpg' },
    { id: 3, name: 'Plank', category: 'Core', difficulty: 'Beginner', muscles: 'Abs, Lower Back', instructions: 'Get into a forearm plank position...', image: '/assets/exercises/plank.jpg' },
    { id: 4, name: 'Deadlifts', category: 'Full Body', difficulty: 'Intermediate', muscles: 'Back, Glutes, Hamstrings', instructions: 'Stand with feet hip-width apart...', image: '/assets/exercises/deadlift.jpg' },
    { id: 5, name: 'Burpees', category: 'Cardio', difficulty: 'Intermediate', muscles: 'Full Body', instructions: 'Start standing, drop into a squat...', image: '/assets/exercises/burpees.jpg' },
    { id: 6, name: 'Pull-ups', category: 'Upper Body', difficulty: 'Advanced', muscles: 'Back, Biceps', instructions: 'Hang from a bar...', image: '/assets/exercises/pull-ups.jpg' },
  ];

  const filteredExercises = exercises.filter(exercise =>
    exercise.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
    (selectedCategory === 'All' || exercise.category === selectedCategory)
  );

  const handleExerciseClick = (exercise) => {
    const normalizedExerciseName = exercise.name.toLowerCase().replace(/s$/, '');
    setSelectedExercise({ ...exercise, normalizedName: normalizedExerciseName });
    setVideoModalOpen(true);
  };

  const closeVideoModal = () => {
    setVideoModalOpen(false);
    setSelectedExercise(null);
    setShowCamera(false); // reset camera view
  };
  
  /*
  const closeVideoModal = () => {
    setVideoModalOpen(false);
    setSelectedExercise(null);
  };*/

  return (
    <motion.div
      className="workout-container"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.4 }}
    >
      <motion.h1 className="workout-title" initial={{ y: -10, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.2 }}>
        Workout Exercises
      </motion.h1>

      <motion.div className="search-filter-container" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }}>
        <div className="search-bar">
          <Search className="search-icon" size={20} />
          <input
            type="text"
            placeholder="Search exercises..."
            className="search-input"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <div className="category-dropdown">
          <select
            className="dropdown-select"
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
          >
            {categories.map((category) => (
              <option key={category} value={category}>{category}</option>
            ))}
          </select>
          <ChevronDown className="dropdown-icon" size={20} />
        </div>
      </motion.div>

      <motion.div className="exercises-grid" layout>
        <AnimatePresence>
          {filteredExercises.map((exercise) => (
            <motion.div
              layout
              key={exercise.id}
              className="exercise-card"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              whileHover={{ scale: 1.03 }}
            >
              <img src={exercise.image} alt={exercise.name} className="exercise-image" />
              <div className="exercise-content">
                <h3 className="exercise-name">{exercise.name}</h3>
                <div className="exercise-details">
                  <p><strong>Category:</strong> {exercise.category}</p>
                  <p><strong>Difficulty:</strong> {exercise.difficulty}</p>
                  <p><strong>Targets:</strong> {exercise.muscles}</p>
                </div>
                <button onClick={() => handleExerciseClick(exercise)} className="start-btn">
                  <Play size={16} /> Start Tracking
                </button>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </motion.div>

      {filteredExercises.length === 0 && (
        <div className="no-results">
          <p>No exercises found matching your search criteria.</p>
          <button onClick={() => { setSearchQuery(''); setSelectedCategory('All'); }}>
            Clear filters
          </button>
        </div>
      )}
      

      
      <AnimatePresence>
  {videoModalOpen && selectedExercise && (
    <motion.div
      className="modal-overlay"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <motion.div
        className="modal"
        initial={{ scale: 0.95, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.95, y: 20 }}
        transition={{ duration: 0.3 }}
      >
        <div className="modal-header">
          <h3>{selectedExercise.name} - Instructions</h3>
          <button onClick={closeVideoModal}><X size={30} /></button>
        </div>

        <div className="modal-body">
        {showCamera ? (
  <motion.div
    className="camera-fullscreen-overlay"
    initial={{ opacity: 0 }}
    animate={{ opacity: 1 }}
    exit={{ opacity: 0 }}
  >
    <div className="camera-header">
      <h3>{selectedExercise.name} - Tracking</h3>
      <button onClick={closeVideoModal}><X size={30} /></button>
    </div>
    <div className="camera-body">
      <CameraFeed exerciseType={selectedExercise.normalizedName} />
    </div>
    <div className="camera-footer">
      <button onClick={closeVideoModal} className="finish-btn">Finish Workout</button>
    </div>
  </motion.div>
) : (
  <>
    <div className="instructions">
      <h4>Instructions</h4>
      <p>{selectedExercise.instructions}</p>
      <h4>Form Tips</h4>
      <ul>
        <li>Keep your movements controlled and deliberate</li>
        <li>Maintain proper posture throughout the exercise</li>
        <li>Focus on engaging the target muscles</li>
        <li>Breathe properly - exhale during exertion</li>
      </ul>
      <h4>Tracking Stats</h4>
      <div className="stats-box">
        <p><strong>Reps completed:</strong> 0</p>
        <p><strong>Form accuracy:</strong> N/A</p>
        <p><strong>Time elapsed:</strong> 00:00</p>
      </div>
    </div>

    <div className="demo-video">
    <video controls width="100%" height="auto">
      <source src={`/assets/demovids/${selectedExercise.normalizedName}.mp4`} type="video/mp4" />
      Your browser does not support the video tag.
    </video>
    </div>

  <div className="modal-footer">
    <button onClick={closeVideoModal}>Cancel</button>
    <button className="start-btn" onClick={() => setShowCamera(true)}>Start</button>
  </div>
  </>
)}

        </div>
      </motion.div>
    </motion.div>
  )}
</AnimatePresence>

      
    </motion.div>
  );
};

export default WorkoutPage;


/*import React, { useState } from 'react';
import { X, Search, ChevronDown, Play } from 'lucide-react';
import CameraFeed from './components/CameraFeed'; // Importing the live camera feed component
import './WorkoutPage.css';

const WorkoutPage = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [videoModalOpen, setVideoModalOpen] = useState(false);
  const [selectedExercise, setSelectedExercise] = useState(null);

  const categories = ['All', 'Upper Body', 'Lower Body', 'Core', 'Cardio', 'Full Body'];

  const exercises = [
    { id: 1, name: 'Push-ups', category: 'Upper Body', difficulty: 'Beginner', muscles: 'Chest, Shoulders, Triceps', instructions: 'Start in a plank position...', image: '/api/placeholder/320/180' },
    { id: 2, name: 'Squats', category: 'Lower Body', difficulty: 'Beginner', muscles: 'Quads, Hamstrings, Glutes', instructions: 'Stand with feet shoulder-width apart...', image: '/api/placeholder/320/180' },
    { id: 3, name: 'Plank', category: 'Core', difficulty: 'Beginner', muscles: 'Abs, Lower Back', instructions: 'Get into a forearm plank position...', image: '/api/placeholder/320/180' },
    { id: 4, name: 'Deadlifts', category: 'Full Body', difficulty: 'Intermediate', muscles: 'Back, Glutes, Hamstrings', instructions: 'Stand with feet hip-width apart...', image: '/api/placeholder/320/180' },
    { id: 5, name: 'Burpees', category: 'Cardio', difficulty: 'Intermediate', muscles: 'Full Body', instructions: 'Start standing, drop into a squat...', image: '/api/placeholder/320/180' },
    { id: 6, name: 'Pull-ups', category: 'Upper Body', difficulty: 'Advanced', muscles: 'Back, Biceps', instructions: 'Hang from a bar...', image: '/api/placeholder/320/180' },
  ];

  const filteredExercises = exercises.filter(exercise =>
    exercise.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
    (selectedCategory === 'All' || exercise.category === selectedCategory)
  );

  const handleExerciseClick = (exercise) => {
    const normalizedExerciseName = exercise.name.toLowerCase().replace(/s$/, ''); // Convert to lowercase and remove trailing 's'
    setSelectedExercise({ ...exercise, normalizedName: normalizedExerciseName });
    setVideoModalOpen(true);
  };

  const closeVideoModal = () => {
    setVideoModalOpen(false);
    setSelectedExercise(null);
  };

  return (
    <div className="workout-container">
      <h1 className="workout-title">Workout Exercises</h1>

      <div className="search-filter-container">
        <div className="search-bar">
          <Search className="search-icon" size={20} />
          <input
            type="text"
            placeholder="Search exercises..."
            className="search-input"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <div className="category-dropdown">
          <select
            className="dropdown-select"
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
          >
            {categories.map((category) => (
              <option key={category} value={category}>{category}</option>
            ))}
          </select>
          <ChevronDown className="dropdown-icon" size={20} />
        </div>
      </div>

      <div className="exercises-grid">
        {filteredExercises.map((exercise) => (
          <div key={exercise.id} className="exercise-card">
            <img src={exercise.image} alt={exercise.name} className="exercise-image" />
            <div className="exercise-content">
              <h3 className="exercise-name">{exercise.name}</h3>
              <div className="exercise-details">
                <p><strong>Category:</strong> {exercise.category}</p>
                <p><strong>Difficulty:</strong> {exercise.difficulty}</p>
                <p><strong>Targets:</strong> {exercise.muscles}</p>
              </div>
              <button onClick={() => handleExerciseClick(exercise)} className="start-btn">
                <Play size={16} /> Start Tracking
              </button>
            </div>
          </div>
        ))}
      </div>

      {filteredExercises.length === 0 && (
        <div className="no-results">
          <p>No exercises found matching your search criteria.</p>
          <button onClick={() => { setSearchQuery(''); setSelectedCategory('All'); }}>
            Clear filters
          </button>
        </div>
      )}

      {videoModalOpen && selectedExercise && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h3>{selectedExercise.name} - Form Tracking</h3>
              <button onClick={closeVideoModal}><X size={24} /></button>
            </div>

            <div className="modal-body">
              {videoModalOpen && (
                <div className="video-feed">
                  <CameraFeed exerciseType={selectedExercise.normalizedName} />
                </div>
              )}
              <div className="instructions">
                <h4>Instructions</h4>
                <p>{selectedExercise.instructions}</p>
                <h4>Form Tips</h4>
                <ul>
                  <li>Keep your movements controlled and deliberate</li>
                  <li>Maintain proper posture throughout the exercise</li>
                  <li>Focus on engaging the target muscles</li>
                  <li>Breathe properly - exhale during exertion</li>
                </ul>
                <h4>Tracking Stats</h4>
                <div className="stats-box">
                  <p><strong>Reps completed:</strong> 0</p>
                  <p><strong>Form accuracy:</strong> N/A</p>
                  <p><strong>Time elapsed:</strong> 00:00</p>
                </div>
              </div>
            </div>

            <div className="modal-footer">
              <button onClick={closeVideoModal}>Cancel</button>
              <button className="finish-btn" onClick={closeVideoModal}>Finish Workout</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default WorkoutPage;
*/


















/*
      <AnimatePresence>
        {videoModalOpen && selectedExercise && (
          <motion.div
            className="modal-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="modal"
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              transition={{ duration: 0.3 }}
            >
              <div className="modal-header">
                <h3>{selectedExercise.name} - Form Tracking</h3>
                <button onClick={closeVideoModal}><X size={30} /></button>
              </div>

              <div className="modal-body">
                <div className="video-feed">
                  <CameraFeed exerciseType={selectedExercise.normalizedName} />
                </div>
                <div className="instructions">
                  <h4>Instructions</h4>
                  <p>{selectedExercise.instructions}</p>
                  <h4>Form Tips</h4>
                  <ul>
                    <li>Keep your movements controlled and deliberate</li>
                    <li>Maintain proper posture throughout the exercise</li>
                    <li>Focus on engaging the target muscles</li>
                    <li>Breathe properly - exhale during exertion</li>
                  </ul>
                  <h4>Tracking Stats</h4>
                  <div className="stats-box">
                    <p><strong>Reps completed:</strong> 0</p>
                    <p><strong>Form accuracy:</strong> N/A</p>
                    <p><strong>Time elapsed:</strong> 00:00</p>
                  </div>
                </div>
              </div>

              <div className="modal-footer">
                <button onClick={closeVideoModal}>Cancel</button>
                <button className="finish-btn" onClick={closeVideoModal}>Finish Workout</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      */





/*

      {!showCamera ? (
        <>
          <div className="instructions">
            <h4>Instructions</h4>
            <p>{selectedExercise.instructions}</p>
            <h4>Form Tips</h4>
            <ul>
              <li>Keep your movements controlled and deliberate</li>
              <li>Maintain proper posture throughout the exercise</li>
              <li>Focus on engaging the target muscles</li>
              <li>Breathe properly - exhale during exertion</li>
            </ul>
            <h4>Tracking Stats</h4>
            <div className="stats-box">
              <p><strong>Reps completed:</strong> 0</p>
              <p><strong>Form accuracy:</strong> N/A</p>
              <p><strong>Time elapsed:</strong> 00:00</p>
            </div>
          </div>
          <div className="modal-footer">
            <button onClick={closeVideoModal}>Cancel</button>
            <button className="start-btn" onClick={() => setShowCamera(true)}>Start</button>
          </div>
        </>
      ) : (
        <>
          <div className="video-feed-fullscreen">
            <CameraFeed exerciseType={selectedExercise.normalizedName} />
          </div>
          <div className="modal-footer">
            <button onClick={closeVideoModal}>Finish Workout</button>
          </div>
        </>
      )}     */