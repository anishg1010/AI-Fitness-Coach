import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { Dumbbell, Home, Utensils, Menu, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

import HomePage from './HomePage';
import WorkoutPage from './WorkoutPage';
import DietRecommenderPage from './DietRecommenderPage';
import './App.css';

const AnimatedRoutes = () => {
  const location = useLocation();

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={location.pathname}
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -15 }}
        transition={{ duration: 0.4, ease: 'easeInOut' }}
      >
        <Routes location={location}>
          <Route path="/" element={<HomePage />} />
          <Route path="/workout" element={<WorkoutPage />} />
          <Route path="/diet" element={<DietRecommenderPage />} />
        </Routes>
      </motion.div>
    </AnimatePresence>
  );
};

const App = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const toggleMobileMenu = () => setMobileMenuOpen(prev => !prev);

  return (
    <Router>
      <div className="app-container font-sans">
        <header className="navbar shadow-md">
          <div className="navbar-inner">
            <div className="logo-container">
              <motion.span
                className="logo-text"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4 }}
              >
                FitTrack
              </motion.span>
            </div>

            <nav className="desktop-menu">
              <NavItem to="/" label="Home" icon={<Home size={18} />} />
              <NavItem to="/workout" label="Workouts" icon={<Dumbbell size={18} />} />
              <NavItem to="/diet" label="Diet" icon={<Utensils size={18} />} />
            </nav>

            <div className="mobile-toggle">
              <button className="mobile-button" onClick={toggleMobileMenu}>
                {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>

          <AnimatePresence>
            {mobileMenuOpen && (
              <motion.div
                className="mobile-menu"
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                <MobileNavItem to="/" label="Home" icon={<Home size={18} />} closeMenu={toggleMobileMenu} />
                <MobileNavItem to="/workout" label="Workouts" icon={<Dumbbell size={18} />} closeMenu={toggleMobileMenu} />
                <MobileNavItem to="/diet" label="Diet" icon={<Utensils size={18} />} closeMenu={toggleMobileMenu} />
              </motion.div>
            )}
          </AnimatePresence>
        </header>

        <main className="main-content px-4 py-6">
          <AnimatedRoutes />
        </main>

        <footer className="footer mt-auto">
          <div className="footer-inner">
            <div className="footer-brand">
              <span className="logo-text text-xl">FitTrack</span>
              <p className="footer-subtext text-sm text-gray-500">Your AI-powered fitness companion</p>
            </div>
            <div className="footer-links">
              <Link to="/" className="footer-link">Home</Link>
              <Link to="/workout" className="footer-link">Workouts</Link>
              <Link to="/diet" className="footer-link">Diet</Link>
            </div>
          </div>
          <div className="footer-bottom text-xs text-center py-4 text-gray-400">
            &copy; {new Date().getFullYear()} FitTrack. All rights reserved.
          </div>
        </footer>
      </div>
    </Router>
  );
};

const NavItem = ({ to, label, icon }) => (
  <Link to={to} className="nav-link hover:text-emerald-500 transition-colors duration-200">
    {icon} <span className="ml-1">{label}</span>
  </Link>
);

const MobileNavItem = ({ to, label, icon, closeMenu }) => (
  <motion.div whileTap={{ scale: 0.95 }}>
    <Link to={to} className="mobile-link" onClick={closeMenu}>
      {icon} <span className="ml-1">{label}</span>
    </Link>
  </motion.div>
);

export default App;





/*import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { Dumbbell, Home, Utensils, Menu, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

import HomePage from './HomePage';
import WorkoutPage from './WorkoutPage';
import DietRecommenderPage from './DietRecommenderPage';
import './App.css';

const AnimatedRoutes = () => {
  const location = useLocation();

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={location.pathname}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        transition={{ duration: 0.4 }}
      >
        <Routes location={location}>
          <Route path="/" element={<HomePage />} />
          <Route path="/workout" element={<WorkoutPage />} />
          <Route path="/diet" element={<DietRecommenderPage />} />
        </Routes>
      </motion.div>
    </AnimatePresence>
  );
};

const App = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <Router>
      <div className="app-container">
        <nav className="navbar">
          <div className="navbar-inner">
            <div className="navbar-content">
              <div className="logo-container">
                <motion.span
                  className="logo-text"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.2 }}
                >
                  FitTrack
                </motion.span>
              </div>
              <div className="desktop-menu">
                <NavItem to="/" label="Home" icon={<Home size={18} />} />
                <NavItem to="/workout" label="Workouts" icon={<Dumbbell size={18} />} />
                <NavItem to="/diet" label="Diet" icon={<Utensils size={18} />} />
              </div>
            </div>
            <div className="mobile-toggle">
              <button onClick={toggleMobileMenu} className="mobile-button">
                {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>

          <AnimatePresence>
            {mobileMenuOpen && (
              <motion.div
                className="mobile-menu show"
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                <MobileNavItem to="/" label="Home" icon={<Home size={18} />} onClick={() => setMobileMenuOpen(false)} />
                <MobileNavItem to="/workout" label="Workouts" icon={<Dumbbell size={18} />} onClick={() => setMobileMenuOpen(false)} />
                <MobileNavItem to="/diet" label="Diet" icon={<Utensils size={18} />} onClick={() => setMobileMenuOpen(false)} />
              </motion.div>
            )}
          </AnimatePresence>
        </nav>

        <main>
          <AnimatedRoutes />
        </main>

        <footer className="footer">
          <div className="footer-inner">
            <div className="footer-brand">
              <span className="logo-text">FitTrack</span>
              <p className="footer-subtext">Your AI-powered fitness companion</p>
            </div>
            <div className="footer-links">
              <Link to="/" className="footer-link">Home</Link>
              <Link to="/workout" className="footer-link">Workouts</Link>
              <Link to="/diet" className="footer-link">Diet</Link>
            </div>
          </div>
          <div className="footer-bottom">
            <p>&copy; {new Date().getFullYear()} FitTrack. All rights reserved.</p>
          </div>
        </footer>
      </div>
    </Router>
  );
};

const NavItem = ({ to, label, icon }) => (
  <Link to={to} className="nav-link">
    {icon} {label}
  </Link>
);

const MobileNavItem = ({ to, label, icon, onClick }) => (
  <motion.div whileTap={{ scale: 0.95 }}>
    <Link to={to} className="mobile-link" onClick={onClick}>
      {icon} {label}
    </Link>
  </motion.div>
);

export default App;


import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { Dumbbell, Home, Utensils, Menu, X } from 'lucide-react';

import HomePage from './HomePage';
import WorkoutPage from './WorkoutPage';
import DietRecommenderPage from './DietRecommenderPage';
import './App.css'; // Link to your standard CSS file

const App = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <Router>
      <div className="app-container">
        # Navigation
        <nav className="navbar">
          <div className="navbar-inner">
            <div className="navbar-content">
              <div className="logo-container">
                <span className="logo-text">FitTrack</span>
              </div>
              <div className="desktop-menu">
                <Link to="/" className="nav-link active-link">
                  <Home size={18} className="icon" />
                  Home
                </Link>
                <Link to="/workout" className="nav-link">
                  <Dumbbell size={18} className="icon" />
                  Workouts
                </Link>
                <Link to="/diet" className="nav-link">
                  <Utensils size={18} className="icon" />
                  Diet
                </Link>
              </div>
            </div>
            #Mobile menu toggle
            <div className="mobile-toggle">
              <button onClick={toggleMobileMenu} className="mobile-button">
                {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>

          # Mobile menu 
          <div className={`mobile-menu ${mobileMenuOpen ? 'show' : ''}`}>
            <Link to="/" className="mobile-link active-mobile-link" onClick={() => setMobileMenuOpen(false)}>
              <Home size={18} className="icon" /> Home
            </Link>
            <Link to="/workout" className="mobile-link" onClick={() => setMobileMenuOpen(false)}>
              <Dumbbell size={18} className="icon" /> Workouts
            </Link>
            <Link to="/diet" className="mobile-link" onClick={() => setMobileMenuOpen(false)}>
              <Utensils size={18} className="icon" /> Diet
            </Link>
          </div>
        </nav>

        3Main content 
        <main>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/workout" element={<WorkoutPage />} />
            <Route path="/diet" element={<DietRecommenderPage />} />
          </Routes>
        </main>

        #Footer
        <footer className="footer">
          <div className="footer-inner">
            <div className="footer-brand">
              <span className="logo-text">FitTrack</span>
              <p className="footer-subtext">Your AI-powered fitness companion</p>
            </div>
            <div className="footer-links">
              <Link to="/" className="footer-link">Home</Link>
              <Link to="/workout" className="footer-link">Workouts</Link>
              <Link to="/diet" className="footer-link">Diet</Link>
            </div>
          </div>
          <div className="footer-bottom">
            <p>&copy; {new Date().getFullYear()} FitTrack. All rights reserved.</p>
          </div>
        </footer>
      </div>
    </Router>
  );
};

export default App;
*/