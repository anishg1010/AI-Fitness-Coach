
import React, { useState } from 'react';
import './DietRecommenderPage.css';
import { FaCalculator, FaUtensils, FaRedo } from 'react-icons/fa';

export default function DietRecommenderPage() {
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [bmi, setBmi] = useState(null);
  const [category, setCategory] = useState('');
  const [showTable, setShowTable] = useState(false);

  const tableData = {
    'Underweight': [
      ['Meal', 'Time', 'Food', 'Quantity', 'Macros (Carbs, Protein, Fat)', 'Calories'],
      ['Breakfast', '7:30 AM', 'Oatmeal, banana, peanut butter, full-fat milk, 2 eggs', '1 bowl oatmeal, 1 banana, 2 tbsp peanut butter, 1 cup milk, 2 eggs', 'Carbs: 40g, Protein: 15g, Fat: 20g', '450'],
      ['Snack', '10:30 AM', 'Nuts, dried fruits, yogurt smoothie', '30g nuts, 50g dried fruits, 1 cup yogurt', 'Carbs: 25g, Protein: 10g, Fat: 15g', '350'],
      ['Lunch', '1:30 PM', 'Brown rice, chicken, avocado salad, veggies', '1 cup rice, 150g chicken, 1/2 avocado, 1 cup veggies', 'Carbs: 60g, Protein: 30g, Fat: 25g', '600'],
      ['Snack', '4:30 PM', 'Whole wheat toast, peanut butter, milk', '2 slices toast, 2 tbsp peanut butter, 1 cup milk', 'Carbs: 30g, Protein: 10g, Fat: 20g', '400'],
      ['Dinner', '8:00 PM', 'Salmon, mashed sweet potatoes, veggies', '200g salmon, 1 cup sweet potatoes, 1 cup veggies', 'Carbs: 35g, Protein: 40g, Fat: 30g', '700'],
      ['Bed', '10:30 PM', 'Cottage cheese, nuts, dark chocolate', '1/2 cup cottage cheese, 30g nuts, 20g dark chocolate', 'Carbs: 10g, Protein: 20g, Fat: 20g', '350'],
    ],
    'Normal weight': [
      ['Meal', 'Time', 'Food', 'Quantity', 'Macros (Carbs, Protein, Fat)', 'Calories'],
      ['Breakfast', '8:00 AM', 'Scrambled eggs, toast, avocado, black coffee', '2 eggs, 2 slices toast, 1/2 avocado, 1 cup black coffee', 'Carbs: 30g, Protein: 20g, Fat: 25g', '500'],
      ['Snack', '11:00 AM', 'Nuts, fruit smoothie', '30g nuts, 1 cup fruit smoothie', 'Carbs: 35g, Protein: 10g, Fat: 20g', '400'],
      ['Lunch', '2:00 PM', 'Brown rice, grilled chicken, veggies', '1 cup rice, 150g chicken, 1 cup veggies', 'Carbs: 55g, Protein: 40g, Fat: 15g', '600'],
      ['Snack', '5:00 PM', 'Yogurt, honey, flaxseeds', '1 cup yogurt, 1 tbsp honey, 1 tbsp flaxseeds', 'Carbs: 25g, Protein: 15g, Fat: 10g', '300'],
      ['Dinner', '8:30 PM', 'Grilled fish, quinoa, roasted veggies', '200g fish, 1/2 cup quinoa, 1 cup veggies', 'Carbs: 40g, Protein: 35g, Fat: 20g', '650'],
      ['Bed', '10:30 PM', 'Warm milk, almonds', '1 cup milk, 30g almonds', 'Carbs: 10g, Protein: 8g, Fat: 10g', '250'],
    ],
    'Overweight': [
      ['Meal', 'Time', 'Food', 'Quantity', 'Macros (Carbs, Protein, Fat)', 'Calories'],
      ['Breakfast', '7:30 AM', 'Boiled eggs, spinach omelet, toast', '2 boiled eggs, 1 cup spinach, 2 slices toast', 'Carbs: 20g, Protein: 25g, Fat: 15g', '400'],
      ['Snack', '10:30 AM', 'Chia pudding, almonds', '1/2 cup chia seeds, 30g almonds', 'Carbs: 15g, Protein: 8g, Fat: 20g', '350'],
      ['Lunch', '1:30 PM', 'Grilled chicken, quinoa, veggies', '150g chicken, 1/2 cup quinoa, 1 cup veggies', 'Carbs: 40g, Protein: 40g, Fat: 15g', '500'],
      ['Snack', '4:30 PM', 'Green tea, nuts', '1 cup green tea, 30g nuts', 'Carbs: 10g, Protein: 10g, Fat: 15g', '250'],
      ['Dinner', '7:30 PM', 'Baked salmon, sweet potatoes, spinach', '200g salmon, 1 cup sweet potatoes, 1 cup spinach', 'Carbs: 35g, Protein: 45g, Fat: 25g', '700'],
      ['Bed', '10:00 PM', 'Herbal tea, walnuts', '1 cup herbal tea, 30g walnuts', 'Carbs: 5g, Protein: 5g, Fat: 15g', '150'],
    ],
    'Obese': [
      ['Meal', 'Time', 'Food', 'Quantity', 'Macros (Carbs, Protein, Fat)', 'Calories'],
      ['Breakfast', '8:00 AM', 'Egg whites, toast, black coffee', '4 egg whites, 2 slices toast, 1 cup black coffee', 'Carbs: 15g, Protein: 25g, Fat: 10g', '300'],
      ['Snack', '11:00 AM', 'Chia pudding, berries', '1/2 cup chia seeds, 100g berries', 'Carbs: 20g, Protein: 10g, Fat: 15g', '300'],
      ['Lunch', '2:00 PM', 'Grilled chicken salad, olive oil dressing', '150g chicken, 1 cup salad, 1 tbsp olive oil', 'Carbs: 10g, Protein: 40g, Fat: 30g', '450'],
      ['Snack', '5:00 PM', 'Almonds, green tea', '30g almonds, 1 cup green tea', 'Carbs: 5g, Protein: 5g, Fat: 20g', '250'],
      ['Dinner', '7:30 PM', 'Grilled fish, steamed veggies, quinoa', '200g fish, 1 cup veggies, 1/2 cup quinoa', 'Carbs: 35g, Protein: 40g, Fat: 15g', '600'],
      ['Bed', '10:00 PM', 'Herbal tea, flaxseeds', '1 cup herbal tea, 1 tbsp flaxseeds', 'Carbs: 5g, Protein: 5g, Fat: 10g', '150'],
    ],
  };

  const calculateBMI = () => {
    const weightNum = parseFloat(weight);
    const heightNum = parseFloat(height) / 100;

    if (isNaN(weightNum) || isNaN(heightNum) || heightNum <= 0) {
      alert('Please enter valid weight and height.');
      return;
    }

    const bmiValue = weightNum / (heightNum * heightNum);
    const bmiFixed = parseFloat(bmiValue.toFixed(2));
    setBmi(bmiFixed);

    if (bmiFixed < 18.5) setCategory('Underweight');
    else if (bmiFixed < 24.9) setCategory('Normal weight');
    else if (bmiFixed < 29.9) setCategory('Overweight');
    else setCategory('Obese');

    setShowTable(false);
  };

  const generateDietPlan = () => {
    if (!bmi) {
      alert('Please calculate BMI first!');
      return;
    }
    setShowTable(true);
  };

  const clearForm = () => {
    setWeight('');
    setHeight('');
    setBmi(null);
    setCategory('');
    setShowTable(false);
  };

  return (
    <div className="diet-container">
      <h2 className="diet-heading">BMI Calculator & Diet Recommender</h2>

      <div className="input-container">
        <input
          type="number"
          placeholder="Weight (kg)"
          value={weight}
          onChange={(e) => setWeight(e.target.value)}
          className="input-field"
        />
        <input
          type="number"
          placeholder="Height (cm)"
          value={height}
          onChange={(e) => setHeight(e.target.value)}
          className="input-field"
        />
      </div>

      <div className="button-group">
        <button onClick={calculateBMI} className="generate-button">
          <FaCalculator /> Calculate BMI
        </button>
        <button onClick={generateDietPlan} className="generate-button">
          <FaUtensils /> Generate Diet Plan
        </button>
        <button onClick={clearForm} className="clear-button">
          <FaRedo /> Reset
        </button>
      </div>

      {bmi !== null && (
        <div className="result-container show">
          <p>Your BMI: <strong>{bmi}</strong></p>
          <p>Category: <strong>{category}</strong></p>
        </div>
      )}

      {showTable && tableData[category] && (
        <div className="table-wrapper show">
          <h3>Ideal Diet Plan</h3>
          <table className="diet-table">
            <tbody>
              {tableData[category].map((row, index) => (
                <tr key={index}>
                  {row.map((cell, i) => (
                    <td key={i}>{cell}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

/*
import React, { useState } from 'react';
import './DietRecommenderPage.css'; // You can style as needed or use inline

export default function DietRecommenderPage() {
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [bmi, setBmi] = useState(null);
  const [category, setCategory] = useState('');
  const [showTable, setShowTable] = useState(false);

  const tableData = {
    'Underweight': [
      ['Meal', 'Time', 'Food', 'Macros (Carbs, Protein, Fat)', 'Calories'],
      ['Breakfast', '7:30 AM', 'Oatmeal, banana, peanut butter, full-fat milk, 2 eggs', 'Carbs: 40g, Protein: 15g, Fat: 20g', '450'],
      ['Snack', '10:30 AM', 'Nuts, dried fruits, yogurt smoothie', 'Carbs: 25g, Protein: 10g, Fat: 15g', '350'],
      ['Lunch', '1:30 PM', 'Brown rice, chicken, avocado salad, veggies', 'Carbs: 60g, Protein: 30g, Fat: 25g', '600'],
      ['Snack', '4:30 PM', 'Whole wheat toast, peanut butter, milk', 'Carbs: 30g, Protein: 10g, Fat: 20g', '400'],
      ['Dinner', '8:00 PM', 'Salmon, mashed sweet potatoes, veggies', 'Carbs: 35g, Protein: 40g, Fat: 30g', '700'],
      ['Bed', '10:30 PM', 'Cottage cheese, nuts, dark chocolate', 'Carbs: 10g, Protein: 20g, Fat: 20g', '350'],
    ],
    'Normal weight': [
      ['Meal', 'Time', 'Food', 'Macros (Carbs, Protein, Fat)', 'Calories'],
      ['Breakfast', '8:00 AM', 'Scrambled eggs, toast, avocado, black coffee', 'Carbs: 30g, Protein: 20g, Fat: 25g', '500'],
      ['Snack', '11:00 AM', 'Nuts, fruit smoothie', 'Carbs: 35g, Protein: 10g, Fat: 20g', '400'],
      ['Lunch', '2:00 PM', 'Brown rice, grilled chicken, veggies', 'Carbs: 55g, Protein: 40g, Fat: 15g', '600'],
      ['Snack', '5:00 PM', 'Yogurt, honey, flaxseeds', 'Carbs: 25g, Protein: 15g, Fat: 10g', '300'],
      ['Dinner', '8:30 PM', 'Grilled fish, quinoa, roasted veggies', 'Carbs: 40g, Protein: 35g, Fat: 20g', '650'],
      ['Bed', '10:30 PM', 'Warm milk, almonds', 'Carbs: 10g, Protein: 8g, Fat: 10g', '250'],
    ],
    'Overweight': [
      ['Meal', 'Time', 'Food', 'Macros (Carbs, Protein, Fat)', 'Calories'],
      ['Breakfast', '7:30 AM', 'Boiled eggs, spinach omelet, toast', 'Carbs: 20g, Protein: 25g, Fat: 15g', '400'],
      ['Snack', '10:30 AM', 'Chia pudding, almonds', 'Carbs: 15g, Protein: 8g, Fat: 20g', '350'],
      ['Lunch', '1:30 PM', 'Grilled chicken, quinoa, veggies', 'Carbs: 40g, Protein: 40g, Fat: 15g', '500'],
      ['Snack', '4:30 PM', 'Green tea, nuts', 'Carbs: 10g, Protein: 10g, Fat: 15g', '250'],
      ['Dinner', '7:30 PM', 'Baked salmon, sweet potatoes, spinach', 'Carbs: 35g, Protein: 45g, Fat: 25g', '700'],
      ['Bed', '10:00 PM', 'Herbal tea, walnuts', 'Carbs: 5g, Protein: 5g, Fat: 15g', '150'],
    ],
    'Obese': [
      ['Meal', 'Time', 'Food', 'Macros (Carbs, Protein, Fat)', 'Calories'],
      ['Breakfast', '8:00 AM', 'Egg whites, toast, black coffee', 'Carbs: 15g, Protein: 25g, Fat: 10g', '300'],
      ['Snack', '11:00 AM', 'Chia pudding, berries', 'Carbs: 20g, Protein: 10g, Fat: 15g', '300'],
      ['Lunch', '2:00 PM', 'Grilled chicken salad, olive oil dressing', 'Carbs: 10g, Protein: 40g, Fat: 30g', '450'],
      ['Snack', '5:00 PM', 'Almonds, green tea', 'Carbs: 5g, Protein: 5g, Fat: 20g', '250'],
      ['Dinner', '7:30 PM', 'Grilled fish, steamed veggies, quinoa', 'Carbs: 35g, Protein: 40g, Fat: 15g', '600'],
      ['Bed', '10:00 PM', 'Herbal tea, flaxseeds', 'Carbs: 5g, Protein: 5g, Fat: 10g', '150'],
    ],
  };

  const calculateBMI = () => {
    const weightNum = parseFloat(weight);
    const heightNum = parseFloat(height) / 100;

    if (isNaN(weightNum) || isNaN(heightNum) || heightNum <= 0) {
      alert('Please enter valid weight and height.');
      return;
    }

    const bmiValue = weightNum / (heightNum * heightNum);
    const bmiFixed = parseFloat(bmiValue.toFixed(2));
    setBmi(bmiFixed);

    if (bmiFixed < 18.5) setCategory('Underweight');
    else if (bmiFixed < 24.9) setCategory('Normal weight');
    else if (bmiFixed < 29.9) setCategory('Overweight');
    else setCategory('Obese');

    setShowTable(false);
  };

  const generateDietPlan = () => {
    if (!bmi) {
      alert('Please calculate BMI first!');
      return;
    }
    setShowTable(true);
  };

  return (
    <div style={styles.container}>
      <h2 style={styles.title}>BMI Calculator & Diet Recommender</h2>

      <input
        type="number"
        placeholder="Enter weight (kg)"
        value={weight}
        onChange={(e) => setWeight(e.target.value)}
        style={styles.input}
      />
      <input
        type="number"
        placeholder="Enter height (cm)"
        value={height}
        onChange={(e) => setHeight(e.target.value)}
        style={styles.input}
      />
      <button onClick={calculateBMI} style={styles.button}>Calculate BMI</button>

      {bmi !== null && (
        <div style={styles.resultContainer}>
          <p>Your BMI: <strong>{bmi}</strong></p>
          <p>Category: <strong>{category}</strong></p>
          <button onClick={generateDietPlan} style={styles.button}>Generate Diet Plan</button>
        </div>
      )}

      {showTable && tableData[category] && (
        <div style={styles.tableContainer}>
          <h3>Ideal Diet Plan</h3>
          <table style={styles.table}>
            <tbody>
              {tableData[category].map((row, index) => (
                <tr key={index}>
                  {row.map((cell, cellIndex) => (
                    <td key={cellIndex} style={styles.cell}>{cell}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

const styles = {
  container: {
    maxWidth: '600px',
    margin: 'auto',
    padding: '20px',
    fontFamily: 'Arial',
    backgroundColor: '#f9f9f9',
    borderRadius: '10px',
  },
  title: {
    textAlign: 'center',
    marginBottom: '20px',
  },
  input: {
    width: '100%',
    padding: '10px',
    marginBottom: '10px',
    fontSize: '16px',
  },
  button: {
    width: '100%',
    padding: '10px',
    backgroundColor: '#007bff',
    color: '#fff',
    fontSize: '16px',
    marginBottom: '15px',
    cursor: 'pointer',
    border: 'none',
    borderRadius: '5px',
  },
  resultContainer: {
    textAlign: 'center',
    marginTop: '20px',
  },
  tableContainer: {
    marginTop: '20px',
    overflowX: 'auto',
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
    marginTop: '10px',
  },
  cell: {
    border: '1px solid #ccc',
    padding: '10px',
    textAlign: 'left',
  },
};
*/