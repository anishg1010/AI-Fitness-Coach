import React from 'react';
import { Link } from 'react-router-dom';
import { Dumbbell, Utensils, ArrowRight, BarChart2 } from 'lucide-react';
import { motion } from 'framer-motion';
import './HomePage.css';

const HomePage = () => {
  const featuredWorkouts = [
    {
      id: 1,
      name: 'Full Body HIIT',
      duration: '30 min',
      level: 'Intermediate',
      image: '/assets/exercises/full-body-hiit.jpg'
    },
    {
      id: 2,
      name: 'Core Strength',
      duration: '20 min',
      level: 'Beginner',
      image: '/assets/exercises/core.jpg'
    },
    {
      id: 3,
      name: 'Upper Body Push',
      duration: '45 min',
      level: 'Advanced',
      image: '/assets/exercises/upper-body.jpg'
    }
  ];

  const fadeUp = {
    hidden: { opacity: 0, y: 20 },
    visible: (i = 1) => ({
      opacity: 1,
      y: 0,
      transition: { delay: i * 0.2 },
    }),
  };

  return (
    <motion.div className="homepage-container" initial="hidden" animate="visible" variants={fadeUp}>
      
      {/* Hero Section */}
      <motion.section className="hero-section" variants={fadeUp}>
        <h1>Achieve Your Fitness Goals</h1>
        <p>Track your workouts, get personalized diet recommendations, and transform your fitness journey.</p>
        <div className="hero-buttons">
          <Link to="/workout" className="hero-button-start">Start Workout</Link>
          <Link to="/diet" className="hero-button-diet">Check Diet Plan</Link>
        </div>
      </motion.section>

      {/* Features */}
      <motion.section className="features-section" variants={fadeUp} custom={2}>
        <h2>What We Offer</h2>
        <div className="features-grid">
          <FeatureCard icon={<Dumbbell />} title="AI Workout Tracking" desc="Real-time form feedback with pose detection." color="blue" />
          <FeatureCard icon={<Utensils />} title="Personalized Diet Plans" desc="Custom nutrition plans based on your body." color="green" />
          <FeatureCard icon={<BarChart2 />} title="Progress Tracking" desc="Visualize progress with real data & insights." color="purple" />
        </div>
      </motion.section>

      {/* Featured Workouts */}
      <motion.section className="featured-workouts" variants={fadeUp} custom={3}>
        <div className="featured-header">
          <h2>Featured Workouts</h2>
          <Link to="/workout" className="view-all">
            View all <ArrowRight size={16} />
          </Link>
        </div>
        <div className="features-grid">
          {featuredWorkouts.map((w, i) => (
            <motion.div className="workout-card" key={w.id} variants={fadeUp} custom={i + 4}>
              <div className="workout-image">
              <img src={w.image} alt={w.name} loading="lazy" />

              </div>
              <div className="workout-details">
                <h3>{w.name}</h3>
                <div className="workout-meta">
                  <span>{w.duration}</span>
                  <span>{w.level}</span>
                </div>
                <Link to={`/workout/${w.id}`} className="start-now">Start Now</Link>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.section>

      {/* Quick Start Guide */}
      <motion.section className="quick-start" variants={fadeUp} custom={7}>
        <h2>Quick Start Guide</h2>
        {[1, 2, 3].map((step) => (
          <div key={step} className="step">
            <div className="step-icon">{step}</div>
            <div className="step-text">
              <h3>
                {step === 1 ? 'Browse exercises' : step === 2 ? 'Start workout tracking' : 'Get diet recommendations'}
              </h3>
              <p>
                {step === 1
                  ? 'Explore exercises by muscle group and difficulty.'
                  : step === 2
                  ? 'Use our AI to track and improve your form.'
                  : 'Receive nutrition advice tailored to your body.'}
              </p>
            </div>
          </div>
        ))}
      </motion.section>

      {/* CTA Section */}
      <motion.section className="cta-section" variants={fadeUp} custom={8}>
        <h2>Ready to transform your fitness journey?</h2>
        <p>Start tracking your workouts and get AI-powered nutrition guidance now.</p>
        <Link to="/workout" className="cta-button">Explore Workouts</Link>
      </motion.section>
    </motion.div>
  );
};

const FeatureCard = ({ icon, title, desc, color }) => (
  <motion.div className="feature-card" whileHover={{ scale: 1.05 }}>
    <div className={`feature-icon icon-${color}`}>{icon}</div>
    <h3>{title}</h3>
    <p>{desc}</p>
  </motion.div>
);

export default HomePage;
/*import React from 'react';
import { Link } from 'react-router-dom';
import { Dumbbell, Utensils, ArrowRight, BarChart2 } from 'lucide-react';
import './HomePage.css';

const HomePage = () => {
  const featuredWorkouts = [
    { id: 1, name: 'Full Body HIIT', duration: '30 min', level: 'Intermediate' },
    { id: 2, name: 'Core Strength', duration: '20 min', level: 'Beginner' },
    { id: 3, name: 'Upper Body Push', duration: '45 min', level: 'Advanced' },
  ];

  return (
    <div className="homepage-container">
      # Hero Section 
      <section className="hero-section">
        <div className="hero-content">
          <h1 className="hero-title">Achieve Your Fitness Goals</h1>
          <p className="hero-description">
            Track your workouts, get personalized diet recommendations, and transform your fitness journey.
          </p>
          <div className="hero-buttons">
            <Link to="/workout" className="primary-button">Start Workout</Link>
            <Link to="/diet" className="secondary-button">Check Diet Plan</Link>
          </div>
        </div>
      </section>

      #Features Section 
      <section className="features-section">
        <h2 className="section-title">What We Offer</h2>
        <div className="features-grid">
          <div className="feature-card">
            <div className="icon-wrapper blue">
              <Dumbbell />
            </div>
            <h3 className="feature-title">AI Workout Tracking</h3>
            <p>Real-time pose detection and feedback to ensure proper form during exercises.</p>
          </div>
          <div className="feature-card">
            <div className="icon-wrapper green">
              <Utensils />
            </div>
            <h3 className="feature-title">Personalized Diet Plans</h3>
            <p>Get customized nutrition recommendations based on your body metrics and goals.</p>
          </div>
          <div className="feature-card">
            <div className="icon-wrapper purple">
              <BarChart2 />
            </div>
            <h3 className="feature-title">Progress Tracking</h3>
            <p>Monitor your fitness journey with detailed stats and achievements.</p>
          </div>
        </div>
      </section>

      #Featured Workouts 
      <section className="workouts-section">
        <div className="workouts-header">
          <h2 className="section-title">Featured Workouts</h2>
          <Link to="/workout" className="view-all-link">
            View all <ArrowRight size={16} />
          </Link>
        </div>
        <div className="workouts-grid">
          {featuredWorkouts.map((workout) => (
            <div key={workout.id} className="workout-card">
              <div className="workout-thumbnail"></div>
              <div className="workout-content">
                <h3>{workout.name}</h3>
                <div className="workout-meta">
                  <span>{workout.duration}</span>
                  <span>{workout.level}</span>
                </div>
                <Link to={`/workout/${workout.id}`} className="workout-button">
                  Start Now
                </Link>
              </div>
            </div>
          ))}
        </div>
      </section>

      #Quick Start Guide
      <section className="quick-start-section">
        <h2 className="section-title">Quick Start Guide</h2>
        <div className="quick-steps">
          {[1, 2, 3].map((step) => (
            <div className="quick-step" key={step}>
              <div className="step-number">{step}</div>
              <div>
                <h3 className="step-title">
                  {step === 1 ? 'Browse exercises' : step === 2 ? 'Start workout tracking' : 'Get diet recommendations'}
                </h3>
                <p>
                  {step === 1
                    ? 'Explore our collection of exercises organized by muscle groups and difficulty levels.'
                    : step === 2
                    ? 'Click on an exercise to begin AI-powered form tracking and get real-time feedback.'
                    : 'Enter your information to receive personalized nutrition advice tailored to your needs.'}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      #CTA Section 
      <section className="cta-section">
        <h2 className="section-title white">Ready to transform your fitness journey?</h2>
        <p className="cta-text">
          Start tracking your workouts with AI assistance and get personalized diet recommendations today.
        </p>
        <div className="hero-buttons">
          <Link to="/workout" className="primary-button light">Explore Workouts</Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
*/